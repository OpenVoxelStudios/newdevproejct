# buttons created via BDEngine

execute as @e[tag=buttons_root,type=block_display] at @s run tag @s add sound_pause