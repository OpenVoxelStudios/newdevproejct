# buttons created via BDEngine

execute as @e[type=minecraft:block_display,tag=buttons] on passengers run kill @s
execute as @e[type=minecraft:block_display,tag=buttons] run kill @s
