# buttons created via BDEngine

execute as @e[tag=buttons_root,type=block_display] unless entity @s[tag=animation_pause] at @s run function buttons:k/default/keyframe_1