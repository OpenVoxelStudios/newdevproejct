# buttons created via BDEngine
data merge entity @e[type=item_display,tag=buttons_8,distance=..1,limit=1,sort=nearest] {transformation:[0.375f,0f,0f,0.412109375f,0f,0.375f,0f,1.068359375f,0f,0f,0.375f,0.412109375f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=buttons_9,distance=..1,limit=1,sort=nearest] {transformation:[0.375f,0f,0f,0.599609375f,0f,0.375f,0f,1.068359375f,0f,0f,0.375f,0.412109375f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=buttons_10,distance=..1,limit=1,sort=nearest] {transformation:[0.375f,0f,0f,0.599609375f,0f,0.375f,0f,1.068359375f,0f,0f,0.375f,0.599609375f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=buttons_11,distance=..1,limit=1,sort=nearest] {transformation:[0.375f,0f,0f,0.412109375f,0f,0.375f,0f,1.068359375f,0f,0f,0.375f,0.599609375f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=buttons_12,distance=..1,limit=1,sort=nearest] {transformation:[0.375f,0f,0f,0.599609375f,0f,0.375f,0f,1.255859375f,0f,0f,0.375f,0.599609375f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=buttons_13,distance=..1,limit=1,sort=nearest] {transformation:[0.375f,0f,0f,0.412109375f,0f,0.375f,0f,1.255859375f,0f,0f,0.375f,0.599609375f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=buttons_14,distance=..1,limit=1,sort=nearest] {transformation:[0.375f,0f,0f,0.412109375f,0f,0.375f,0f,1.255859375f,0f,0f,0.375f,0.412109375f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=buttons_15,distance=..1,limit=1,sort=nearest] {transformation:[0.375f,0f,0f,0.599609375f,0f,0.375f,0f,1.255859375f,0f,0f,0.375f,0.412109375f,0f,0f,0f,1f],interpolation_duration:0}
schedule function buttons:k/default/check_pause_0 0.1s
