# buttons created via BDEngine

execute as @e[tag=buttons_root,type=block_display] if entity @s[tag=animation_loop] at @s run function buttons:k/default/keyframe_0
execute as @e[tag=buttons_root,type=block_display] unless entity @s[tag=animation_loop] at @s run function buttons:_/stop_anim