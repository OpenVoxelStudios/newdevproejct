# speaker created via BDEngine

execute as @e[type=minecraft:block_display,tag=speaker] on passengers run kill @s
execute as @e[type=minecraft:block_display,tag=speaker] run kill @s
