# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_0,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,0.8090169944f,0.5877852523f,1.9045084972f,0f,-0.5877852523f,0.8090169944f,-0.2938926261f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/bad_joke/check_pause_3 0.1s
