# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_0,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,0.5571241053f,0.8304292452f,1.7785620526f,0f,-0.8304292452f,0.5571241053f,-0.4152146226f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/bad_joke/check_pause_8 0.1s
