# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_0,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,0.956304756f,0.2923717047f,1.978152378f,0f,-0.2923717047f,0.956304756f,-0.1461858524f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/bad_joke/check_pause_16 0.1s
