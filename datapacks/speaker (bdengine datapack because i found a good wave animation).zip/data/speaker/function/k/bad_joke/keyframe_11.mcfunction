# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_0,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,0.6117242991f,0.7910710347f,1.8058621496f,0f,-0.7910710347f,0.6117242991f,-0.3955355173f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/bad_joke/check_pause_11 0.1s
