# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_0,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,0.9025852843f,0.4305110968f,1.9512926422f,0f,-0.4305110968f,0.9025852843f,-0.2152555484f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/bad_joke/check_pause_15 0.1s
