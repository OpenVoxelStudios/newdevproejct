# speaker created via BDEngine

execute as @e[tag=speaker_root,type=block_display] unless entity @s[tag=animation_pause] at @s run function speaker:k/wave/keyframe_9