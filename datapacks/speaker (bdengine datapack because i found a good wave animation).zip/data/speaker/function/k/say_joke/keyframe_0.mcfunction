# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_0,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,1f,0f,2f,0f,0f,1f,0f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_1,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,0.5f,0f,1.5f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_2,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,1f,0f,1.25f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_3,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.1246875f,0f,0.5f,0f,0.75f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_4,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.1246875f,0f,1f,0f,0.5f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_5,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,0.1253125f,0f,0.5f,0f,0.75f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_6,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,0.1253125f,0f,1f,0f,0.5f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_7,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,0.3753125f,0f,0.5f,0f,1.5f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_8,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,0.3753125f,0f,1f,0f,1.25f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_9,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,0.5f,0f,1.5f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_10,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,1f,0f,1.25f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:0}
data merge entity @e[type=item_display,tag=speaker_11,distance=..1,limit=1,sort=nearest] {transformation:[0.3302188668f,0.3302188668f,0f,0.0539688814f,-0.3302188668f,0.3302188668f,0f,1.168343848f,0f,0f,0.467f,-0.0429062499f,0f,0f,0f,1f],interpolation_duration:0}
schedule function speaker:k/say_joke/check_pause_0 0.1s
