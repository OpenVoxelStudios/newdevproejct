# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_0,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,0.9659258263f,-0.2588190451f,1.9829629131f,0f,0.2588190451f,0.9659258263f,0.1294095226f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/say_joke/check_pause_11 0.1s
