# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_0,distance=..1,limit=1,sort=nearest] {transformation:[1f,0f,0f,0.000625f,0f,1f,0f,2f,0f,0f,1f,0f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/say_joke/check_loop 0.1s
