# speaker created via BDEngine
schedule function speaker:k/say_joke/check_pause_7 0.1s
