# speaker created via BDEngine

execute as @e[tag=speaker_root,type=block_display] unless entity @s[tag=animation_pause] at @s run function speaker:k/say_joke/keyframe_4