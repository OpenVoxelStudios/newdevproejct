# speaker created via BDEngine

execute as @e[tag=speaker_root,type=block_display] at @s run function speaker:k/look_at_card/keyframe_0
