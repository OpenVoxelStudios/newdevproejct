# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_9,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,0.4330127019f,-0.25f,1.4830969255f,0f,0.25f,0.4330127019f,0.0627706329f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
data merge entity @e[type=item_display,tag=speaker_10,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,0.8660254038f,-0.25f,1.2665905745f,0f,0.5f,0.4330127019f,-0.0622293671f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/good_joke/check_pause_2 0.1s
