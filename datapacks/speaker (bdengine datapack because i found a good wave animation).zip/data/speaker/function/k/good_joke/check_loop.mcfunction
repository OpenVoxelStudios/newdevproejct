# speaker created via BDEngine

execute as @e[tag=speaker_root,type=block_display] if entity @s[tag=animation_loop] at @s run function speaker:k/good_joke/keyframe_0
execute as @e[tag=speaker_root,type=block_display] unless entity @s[tag=animation_loop] at @s run function speaker:_/stop_anim