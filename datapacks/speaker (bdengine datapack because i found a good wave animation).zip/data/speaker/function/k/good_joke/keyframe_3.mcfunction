# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_9,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,0.3535533906f,-0.3535533906f,1.4631673768f,0f,0.3535533906f,0.3535533906f,0.0886093185f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
data merge entity @e[type=item_display,tag=speaker_10,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,0.7071067812f,-0.3535533906f,1.2863906815f,0f,0.7071067812f,0.3535533906f,-0.0881673768f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/good_joke/check_pause_3 0.1s
