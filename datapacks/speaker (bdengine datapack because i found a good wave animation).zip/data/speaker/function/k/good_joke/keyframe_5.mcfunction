# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_9,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,0.4829629131f,-0.1294095226f,1.4956598473f,0f,0.1294095226f,0.4829629131f,0.0326542325f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
data merge entity @e[type=item_display,tag=speaker_10,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,0.9659258263f,-0.1294095226f,1.2541783908f,0f,0.2588190451f,0.4829629131f,-0.0320505288f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/good_joke/check_pause_5 0.1s
