# speaker created via BDEngine
data merge entity @e[type=item_display,tag=speaker_9,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,0.5f,0f,1.5f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
data merge entity @e[type=item_display,tag=speaker_10,distance=..1,limit=1,sort=nearest] {transformation:[0.5f,0f,0f,-0.3746875f,0f,1f,0f,1.25f,0f,0f,0.5f,0.0003125f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function speaker:k/good_joke/check_loop 0.1s
