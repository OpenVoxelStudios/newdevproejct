tellraw @a "<Speaker> thank you, thank you :)"
function speaker:a/wave/play_anim
schedule function thingy:start_3 2s